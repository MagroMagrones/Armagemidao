export const environment = {
  production: true,
  api_url: 'https://backend.bbwatch.ga'
}
